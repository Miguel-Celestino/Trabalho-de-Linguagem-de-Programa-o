using SistemaIntegradoInformacao.Models;

namespace SistemaIntegradoInformacao.Services;

public class Application
{
    private readonly JsonStore<Hospital> hospitals = new("hospitais.json");
    private readonly JsonStore<UnidadeSaude> units = new("unidades.json");
    private readonly JsonStore<Utente> patients = new("utentes.json");
    private readonly JsonStore<Medico> doctors = new("medicos.json");
    private readonly JsonStore<Consulta> appointments = new("consultas.json");
    private readonly JsonStore<RegistoClinico> records = new("registos_clinicos.json");
    private readonly JsonStore<PartilhaClinica> shares = new("partilhas.json");
    private readonly JsonStore<Utilizador> users = new("utilizadores.json");

    private Utilizador? currentUser;

    public Application() => EnsureDefaultAdmin();

    // Cria o primeiro administrador apenas quando ainda não existem utilizadores.
    private void EnsureDefaultAdmin()
    {
        if (users.GetAll().Count > 0) return;
        var (salt, hash) = SecurityService.CreateHash("Admin@123");
        users.Add(new Utilizador {
            Nome = "Administrador do Sistema",
            NomeUtilizador = "admin",
            Salt = salt,
            HashSenha = hash,
            Perfil = "Administrador"
        });
    }

    public void Run()
    {
        Console.Clear();
        Header();
        if (!Login()) return;

        while (true)
        {
            Console.Clear();
            Header();
            Console.WriteLine($"Sessão: {currentUser!.Nome} | Perfil: {currentUser.Perfil}");
            Console.WriteLine("\n1 - Hospitais");
            Console.WriteLine("2 - Unidades de saúde");
            Console.WriteLine("3 - Utentes");
            Console.WriteLine("4 - Médicos");
            Console.WriteLine("5 - Consultas");
            Console.WriteLine("6 - Registos clínicos");
            Console.WriteLine("7 - Partilha de informação clínica");
            Console.WriteLine("8 - Relatórios");
            Console.WriteLine("9 - Criar cópia de segurança");
            if (currentUser.Perfil == "Administrador") Console.WriteLine("10 - Criar utilizador");
            Console.WriteLine("0 - Terminar sessão");
            Console.Write("\nOpção: ");
            var op = Console.ReadLine();

            switch (op)
            {
                case "1": if (CanManage()) ManageHospitals(); else Denied(); break;
                case "2": if (CanManage()) ManageUnits(); else Denied(); break;
                case "3": ManagePatients(); break;
                case "4": if (CanManage()) ManageDoctors(); else Denied(); break;
                case "5": ManageAppointments(); break;
                case "6": ManageClinicalRecords(); break;
                case "7": ManageSharing(); break;
                case "8": Reports(); break;
                case "9": Backup(); break;
                case "10":
                    if (currentUser.Perfil == "Administrador") CreateUser();
                    else Denied();
                    break;
                case "0": currentUser = null; return;
                default: Message("Opção inválida."); break;
            }
        }
    }

    private bool Login()
    {
        for (int attempt = 1; attempt <= 3; attempt++)
        {
            Console.Write("Utilizador: ");
            string username = Console.ReadLine() ?? "";
            Console.Write("Palavra-passe: ");
            string password = ReadPassword();

            var user = users.GetAll().FirstOrDefault(x =>
                x.NomeUtilizador.Equals(username, StringComparison.OrdinalIgnoreCase));

            if (user != null && SecurityService.Verify(password, user.Salt, user.HashSenha))
            {
                currentUser = user;
                return true;
            }
            Console.WriteLine($"\nCredenciais inválidas. Tentativa {attempt}/3.");
        }
        return false;
    }

    private static string ReadPassword()
    {
        var value = new System.Text.StringBuilder();
        while (true)
        {
            var key = Console.ReadKey(true);
            if (key.Key == ConsoleKey.Enter) break;
            if (key.Key == ConsoleKey.Backspace && value.Length > 0) value.Length--;
            else if (!char.IsControl(key.KeyChar)) value.Append(key.KeyChar);
        }
        Console.WriteLine();
        return value.ToString();
    }

    private bool CanManage() => currentUser?.Perfil == "Administrador";
    private void Header()
    {
        Console.WriteLine("==================================================");
        Console.WriteLine("       SISTEMA INTEGRADO DE INFORMAÇÃO EM SAÚDE");
        Console.WriteLine("==================================================");
    }
    private static void Denied() => Message("Não tem permissão para executar esta operação.");
    private static void Pause() { Console.WriteLine("\nPrima ENTER para continuar..."); Console.ReadLine(); }
    private static void Message(string message) { Console.WriteLine(message); Pause(); }
    private static string Ask(string label) { Console.Write(label); return Console.ReadLine()?.Trim() ?? ""; }
    private static Guid AskGuid(string label)
    {
        while (true)
            if (Guid.TryParse(Ask(label), out var id)) return id;
            else Console.WriteLine("Identificador inválido.");
    }

    private void ManageHospitals()
    {
        Console.Clear(); Header();
        Console.WriteLine("1 - Registar hospital | 2 - Listar hospitais");
        switch (Ask("Opção: "))
        {
            case "1":
                hospitals.Add(new Hospital {
                    Nome = Ask("Nome: "), Provincia = Ask("Província: "),
                    Municipio = Ask("Município: "), Endereco = Ask("Endereço: "),
                    Telefone = Ask("Telefone: ")
                });
                Message("Hospital registado com sucesso."); break;
            case "2":
                foreach (var h in hospitals.GetAll())
                    Console.WriteLine($"{h.Id} | {h.Nome} | {h.Municipio} - {h.Provincia}");
                Pause(); break;
        }
    }

    private void ManageUnits()
    {
        Console.Clear(); Header();
        Console.WriteLine("1 - Registar unidade | 2 - Listar unidades");
        if (Ask("Opção: ") == "1")
        {
            var all = hospitals.GetAll();
            if (!all.Any()) { Message("Registe primeiro um hospital."); return; }
            foreach (var h in all) Console.WriteLine($"{h.Id} | {h.Nome}");
            var hospitalId = AskGuid("ID do hospital: ");
            if (!all.Any(h => h.Id == hospitalId)) { Message("Hospital não encontrado."); return; }
            units.Add(new UnidadeSaude { HospitalId = hospitalId, Nome = Ask("Nome da unidade: "), Tipo = Ask("Tipo (Centro, Posto, Serviço): ") });
            Message("Unidade registada.");
        }
        else
        {
            foreach (var u in units.GetAll()) Console.WriteLine($"{u.Id} | {u.Nome} | {u.Tipo} | Hospital: {u.HospitalId}");
            Pause();
        }
    }

    private void ManagePatients()
    {
        Console.Clear(); Header();
        Console.WriteLine("1 - Registar utente | 2 - Listar utentes | 3 - Pesquisar por número");
        switch (Ask("Opção: "))
        {
            case "1":
                string number = Ask("Número de utente: ");
                if (patients.GetAll().Any(p => p.NumeroUtente == number)) { Message("Esse número já está registado."); return; }
                if (!DateOnly.TryParse(Ask("Data de nascimento (AAAA-MM-DD): "), out var birth)) { Message("Data inválida."); return; }
                patients.Add(new Utente {
                    NumeroUtente = number, NomeCompleto = Ask("Nome completo: "),
                    DataNascimento = birth, Sexo = Ask("Sexo: "),
                    Telefone = Ask("Telefone: "), Endereco = Ask("Endereço: "),
                    GrupoSanguineo = Ask("Grupo sanguíneo: ")
                });
                Message("Utente registado com sucesso."); break;
            case "2":
                foreach (var p in patients.GetAll()) PrintPatient(p);
                Pause(); break;
            case "3":
                string query = Ask("Número: ");
                var found = patients.GetAll().FirstOrDefault(p => p.NumeroUtente == query);
                if (found == null) Console.WriteLine("Utente não encontrado."); else PrintPatient(found);
                Pause(); break;
        }
    }

    private static void PrintPatient(Utente p) =>
        Console.WriteLine($"{p.NumeroUtente} | {p.NomeCompleto} | {p.DataNascimento:yyyy-MM-dd} | {p.Sexo} | {p.Telefone}");

    private void ManageDoctors()
    {
        Console.Clear(); Header();
        Console.WriteLine("1 - Registar médico | 2 - Listar médicos");
        if (Ask("Opção: ") == "1")
        {
            var hs = hospitals.GetAll();
            if (!hs.Any()) { Message("Registe primeiro um hospital."); return; }
            foreach (var h in hs) Console.WriteLine($"{h.Id} | {h.Nome}");
            var hid = AskGuid("ID do hospital: ");
            if (!hs.Any(h => h.Id == hid)) { Message("Hospital não encontrado."); return; }
            doctors.Add(new Medico { NomeCompleto = Ask("Nome: "), Especialidade = Ask("Especialidade: "), NumeroOrdem = Ask("N.º da ordem: "), HospitalId = hid });
            Message("Médico registado.");
        }
        else
        {
            foreach (var d in doctors.GetAll()) Console.WriteLine($"{d.Id} | {d.NomeCompleto} | {d.Especialidade} | Hospital: {d.HospitalId}");
            Pause();
        }
    }

    private void ManageAppointments()
    {
        Console.Clear(); Header();
        Console.WriteLine("1 - Agendar consulta | 2 - Listar consultas | 3 - Actualizar estado");
        var op = Ask("Opção: ");
        if (op == "1")
        {
            var ps = patients.GetAll(); var ds = doctors.GetAll();
            if (!ps.Any() || !ds.Any()) { Message("É necessário ter pelo menos um utente e um médico registados."); return; }
            foreach (var p in ps) PrintPatient(p);
            var pid = AskGuid("ID do utente (consulte a lista completa no JSON ou registe a pesquisa por número): ");
            if (!ps.Any(p => p.Id == pid)) { Message("Utente não encontrado."); return; }
            foreach (var d in ds) Console.WriteLine($"{d.Id} | {d.NomeCompleto} | {d.Especialidade}");
            var did = AskGuid("ID do médico: ");
            if (!ds.Any(d => d.Id == did)) { Message("Médico não encontrado."); return; }
            if (!DateTime.TryParse(Ask("Data e hora (ex.: 2026-11-20 09:30): "), out var date)) { Message("Data inválida."); return; }
            appointments.Add(new Consulta { UtenteId = pid, MedicoId = did, DataHora = date, Observacoes = Ask("Observações: ") });
            Message("Consulta agendada."); 
        }
        else if (op == "2")
        {
            foreach (var a in appointments.GetAll())
                Console.WriteLine($"{a.Id} | Utente: {a.UtenteId} | Médico: {a.MedicoId} | {a.DataHora:g} | {a.Estado}");
            Pause();
        }
        else if (op == "3")
        {
            var id = AskGuid("ID da consulta: ");
            var list = appointments.GetAll(); var item = list.FirstOrDefault(a => a.Id == id);
            if (item == null) { Message("Consulta não encontrada."); return; }
            item.Estado = Ask("Novo estado (Agendada, Realizada, Cancelada): ");
            var store = new JsonStore<Consulta>("consultas.json"); store.SaveAll(list);
            Message("Estado actualizado.");
        }
    }

    private void ManageClinicalRecords()
    {
        Console.Clear(); Header();
        Console.WriteLine("1 - Registar diagnóstico | 2 - Consultar histórico do utente");
        var op = Ask("Opção: ");
        if (op == "1")
        {
            var ps = patients.GetAll(); var ds = doctors.GetAll();
            if (!ps.Any() || !ds.Any()) { Message("Registe utentes e médicos primeiro."); return; }
            foreach (var p in ps) PrintPatient(p);
            var pid = AskGuid("ID do utente: ");
            if (!ps.Any(p => p.Id == pid)) { Message("Utente não encontrado."); return; }
            foreach (var d in ds) Console.WriteLine($"{d.Id} | {d.NomeCompleto}");
            var did = AskGuid("ID do médico: ");
            if (!ds.Any(d => d.Id == did)) { Message("Médico não encontrado."); return; }
            records.Add(new RegistoClinico { UtenteId = pid, MedicoId = did, Diagnostico = Ask("Diagnóstico: "), Tratamento = Ask("Tratamento: "), Observacoes = Ask("Observações: ") });
            Message("Registo clínico guardado.");
        }
        else if (op == "2")
        {
            var pid = AskGuid("ID do utente: ");
            foreach (var r in records.GetAll().Where(r => r.UtenteId == pid))
                Console.WriteLine($"{r.DataRegisto:g} | Diagnóstico: {r.Diagnostico} | Tratamento: {r.Tratamento} | Médico: {r.MedicoId}");
            Pause();
        }
    }

    private void ManageSharing()
    {
        Console.Clear(); Header();
        var ps = patients.GetAll(); var hs = hospitals.GetAll();
        if (!ps.Any() || hs.Count < 2) { Message("É necessário ter utentes e pelo menos dois hospitais."); return; }
        Console.WriteLine("UTENTES"); foreach (var p in ps) PrintPatient(p);
        var pid = AskGuid("ID do utente: ");
        if (!ps.Any(p => p.Id == pid)) { Message("Utente não encontrado."); return; }
        Console.WriteLine("HOSPITAIS"); foreach (var h in hs) Console.WriteLine($"{h.Id} | {h.Nome}");
        var origin = AskGuid("ID do hospital de origem: ");
        var destination = AskGuid("ID do hospital de destino: ");
        if (origin == destination || !hs.Any(h => h.Id == origin) || !hs.Any(h => h.Id == destination)) { Message("Hospitais inválidos."); return; }
        shares.Add(new PartilhaClinica { UtenteId = pid, HospitalOrigemId = origin, HospitalDestinoId = destination, Motivo = Ask("Motivo da partilha/transferência: ") });
        Message("Pedido de partilha registado. A partilha real exige canal seguro e autorização institucional.");
    }

    private void Reports()
    {
        Console.Clear(); Header();
        Console.WriteLine("========== RELATÓRIO GERAL ==========");
        Console.WriteLine($"Hospitais: {hospitals.GetAll().Count}");
        Console.WriteLine($"Unidades de saúde: {units.GetAll().Count}");
        Console.WriteLine($"Utentes: {patients.GetAll().Count}");
        Console.WriteLine($"Médicos: {doctors.GetAll().Count}");
        Console.WriteLine($"Consultas: {appointments.GetAll().Count}");
        Console.WriteLine($"Registos clínicos: {records.GetAll().Count}");
        Console.WriteLine($"Partilhas registadas: {shares.GetAll().Count}");
        Console.WriteLine("=====================================");
        Pause();
    }

    private void CreateUser()
    {
        Console.Clear(); Header();
        string username = Ask("Nome de utilizador: ");
        var all = users.GetAll();
        if (all.Any(u => u.NomeUtilizador.Equals(username, StringComparison.OrdinalIgnoreCase))) { Message("Nome de utilizador já existe."); return; }
        string password = Ask("Palavra-passe inicial: ");
        if (password.Length < 8) { Message("A palavra-passe deve ter pelo menos 8 caracteres."); return; }
        string role = Ask("Perfil (Administrador, Médico, Funcionário): ");
        if (!new[] { "Administrador", "Médico", "Funcionário" }.Contains(role)) { Message("Perfil inválido."); return; }
        var (salt, hash) = SecurityService.CreateHash(password);
        users.Add(new Utilizador { Nome = Ask("Nome completo: "), NomeUtilizador = username, Salt = salt, HashSenha = hash, Perfil = role });
        Message("Utilizador criado.");
    }

    // Cria uma cópia dos ficheiros de dados com data e hora no nome da pasta.
    private void Backup()
    {
        string source = Path.Combine(Directory.GetCurrentDirectory(), "Data");
        string destination = Path.Combine(Directory.GetCurrentDirectory(), "Backups", DateTime.Now.ToString("yyyyMMdd_HHmmss"));
        Directory.CreateDirectory(destination);
        foreach (var file in Directory.GetFiles(source))
            File.Copy(file, Path.Combine(destination, Path.GetFileName(file)), true);
        Message($"Cópia de segurança criada em: {destination}");
    }
}
