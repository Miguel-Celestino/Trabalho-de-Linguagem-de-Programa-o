using System.Text.Json;

namespace SistemaIntegradoInformacao.Services;

// Esta classe centraliza a leitura e gravação dos ficheiros JSON.
public class JsonStore<T> where T : class
{
    private readonly string _path;
    private readonly JsonSerializerOptions _options = new() { WriteIndented = true };

    public JsonStore(string fileName)
    {
        Directory.CreateDirectory("Data");
        _path = Path.Combine("Data", fileName);
        if (!File.Exists(_path))
            File.WriteAllText(_path, "[]");
    }

    public List<T> GetAll()
    {
        try
        {
            var json = File.ReadAllText(_path);
            return JsonSerializer.Deserialize<List<T>>(json, _options) ?? new List<T>();
        }
        catch (JsonException)
        {
            // Evita que um ficheiro JSON inválido encerre inesperadamente o programa.
            return new List<T>();
        }
    }

    public void SaveAll(List<T> items)
    {
        var json = JsonSerializer.Serialize(items, _options);
        File.WriteAllText(_path, json);
    }

    public void Add(T item)
    {
        var items = GetAll();
        items.Add(item);
        SaveAll(items);
    }
}
