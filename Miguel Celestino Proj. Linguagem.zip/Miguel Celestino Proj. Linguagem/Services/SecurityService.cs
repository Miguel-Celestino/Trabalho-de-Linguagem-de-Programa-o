using System.Security.Cryptography;
using SistemaIntegradoInformacao.Models;

namespace SistemaIntegradoInformacao.Services;

// Guarda e valida palavras-passe através de PBKDF2, nunca em texto simples.
public static class SecurityService
{
    public static (string Salt, string Hash) CreateHash(string password)
    {
        byte[] salt = RandomNumberGenerator.GetBytes(16);
        byte[] hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, 200_000,
            HashAlgorithmName.SHA256, 32);
        return (Convert.ToBase64String(salt), Convert.ToBase64String(hash));
    }

    public static bool Verify(string password, string saltText, string hashText)
    {
        try
        {
            byte[] salt = Convert.FromBase64String(saltText);
            byte[] expected = Convert.FromBase64String(hashText);
            byte[] actual = Rfc2898DeriveBytes.Pbkdf2(password, salt, 200_000,
                HashAlgorithmName.SHA256, 32);
            return CryptographicOperations.FixedTimeEquals(actual, expected);
        }
        catch (FormatException) { return false; }
    }
}
