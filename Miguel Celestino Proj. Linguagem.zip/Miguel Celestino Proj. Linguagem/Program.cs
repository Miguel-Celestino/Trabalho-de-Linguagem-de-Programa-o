
using System;
using System.Collections.Generic;
using System.Linq;

class Hospital
{
    public int Id;
    public string Nome = "";
    public string Localizacao = "";
}

class Paciente
{
    public int Id;
    public string Nome = "";
    public int Idade;
    public string Sexo = "";
    public string Contacto = "";
    public int HospitalId;
    public List<string> Historico = new();
}

class Medico
{
    public int Id;
    public string Nome = "";
    public string Especialidade = "";
    public int HospitalId;
}

class Consulta
{
    public int Id;
    public int PacienteId;
    public int MedicoId;
    public string Data = "";
    public string Diagnostico = "";
    public string Tratamento = "";
}

class Program
{
    static List<Hospital> hospitais = new();
    static List<Paciente> pacientes = new();
    static List<Medico> medicos = new();
    static List<Consulta> consultas = new();

    static int proximoHospital = 1;
    static int proximoPaciente = 1;
    static int proximoMedico = 1;
    static int proximaConsulta = 1;

    static void Main()
    {
        int opcao;

        do
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;

            Console.WriteLine("==============================================");
            Console.WriteLine("       SISTEMA INTEGRADO DE SAUDE");
            Console.WriteLine("       PARTILHA DE DADOS ENTRE HOSPITAIS");
            Console.WriteLine("==============================================");

            Console.ResetColor();

            Console.WriteLine("\n1 - Cadastrar Hospital");
            Console.WriteLine("2 - Cadastrar Paciente");
            Console.WriteLine("3 - Cadastrar Medico");
            Console.WriteLine("4 - Listar Hospitais");
            Console.WriteLine("5 - Listar Pacientes");
            Console.WriteLine("6 - Listar Medicos");
            Console.WriteLine("7 - Registar Consulta");
            Console.WriteLine("8 - Historico Clinico");
            Console.WriteLine("9 - Pesquisar Paciente");
            Console.WriteLine("10 - Partilhar Dados entre Hospitais");
            Console.WriteLine("11 - Relatorios");
            Console.WriteLine("0 - Sair");

            Console.Write("\nEscolha uma opcao: ");

            if (!int.TryParse(Console.ReadLine(), out opcao))
                opcao = -1;

            switch (opcao)
            {
                case 1: CadastrarHospital(); break;
                case 2: CadastrarPaciente(); break;
                case 3: CadastrarMedico(); break;
                case 4: ListarHospitais(); break;
                case 5: ListarPacientes(); break;
                case 6: ListarMedicos(); break;
                case 7: RegistarConsulta(); break;
                case 8: HistoricoClinico(); break;
                case 9: PesquisarPaciente(); break;
                case 10: PartilharDados(); break;
                case 11: Relatorios(); break;
                case 0:
                    Console.WriteLine("\nPrograma encerrado.");
                    break;
                default:
                    Console.WriteLine("\nOpcao invalida!");
                    Pausar();
                    break;
            }

        } while (opcao != 0);
    }

    static void CadastrarHospital()
    {
        Console.Clear();
        Console.WriteLine("=== CADASTRO DE HOSPITAL ===");

        Hospital h = new Hospital();

        h.Id = proximoHospital++;

        Console.Write("Nome do hospital: ");
        h.Nome = Console.ReadLine() ?? "";

        Console.Write("Localizacao: ");
        h.Localizacao = Console.ReadLine() ?? "";

        if (string.IsNullOrWhiteSpace(h.Nome))
        {
            Console.WriteLine("Nome invalido.");
            Pausar();
            return;
        }

        hospitais.Add(h);

        Console.WriteLine("\nHospital cadastrado com sucesso!");
        Pausar();
    }

    static void CadastrarPaciente()
    {
        Console.Clear();
        Console.WriteLine("=== CADASTRO DE PACIENTE ===");

        if (!hospitais.Any())
        {
            Console.WriteLine("Cadastre primeiro um hospital.");
            Pausar();
            return;
        }

        Paciente p = new Paciente();

        p.Id = proximoPaciente++;

        Console.Write("Nome do paciente: ");
        p.Nome = Console.ReadLine() ?? "";

        Console.Write("Idade: ");
        if (!int.TryParse(Console.ReadLine(), out p.Idade) || p.Idade < 0)
        {
            Console.WriteLine("Idade invalida.");
            proximoPaciente--;
            Pausar();
            return;
        }

        Console.Write("Sexo: ");
        p.Sexo = Console.ReadLine() ?? "";

        Console.Write("Contacto: ");
        p.Contacto = Console.ReadLine() ?? "";

        ListarHospitais();

        Console.Write("\nID do hospital: ");

        if (!int.TryParse(Console.ReadLine(), out int hospitalId) ||
            !hospitais.Any(h => h.Id == hospitalId))
        {
            Console.WriteLine("Hospital nao encontrado.");
            proximoPaciente--;
            Pausar();
            return;
        }

        p.HospitalId = hospitalId;

        if (string.IsNullOrWhiteSpace(p.Nome))
        {
            Console.WriteLine("Nome invalido.");
            proximoPaciente--;
            Pausar();
            return;
        }

        pacientes.Add(p);

        Console.WriteLine("\nPaciente cadastrado com sucesso!");
        Pausar();
    }

    static void CadastrarMedico()
    {
        Console.Clear();
        Console.WriteLine("=== CADASTRO DE MEDICO ===");

        if (!hospitais.Any())
        {
            Console.WriteLine("Cadastre primeiro um hospital.");
            Pausar();
            return;
        }

        Medico m = new Medico();

        m.Id = proximoMedico++;

        Console.Write("Nome do medico: ");
        m.Nome = Console.ReadLine() ?? "";

        Console.Write("Especialidade: ");
        m.Especialidade = Console.ReadLine() ?? "";

        ListarHospitais();

        Console.Write("\nID do hospital: ");

        if (!int.TryParse(Console.ReadLine(), out int hospitalId) ||
            !hospitais.Any(h => h.Id == hospitalId))
        {
            Console.WriteLine("Hospital nao encontrado.");
            proximoMedico--;
            Pausar();
            return;
        }

        m.HospitalId = hospitalId;

        if (string.IsNullOrWhiteSpace(m.Nome))
        {
            Console.WriteLine("Nome invalido.");
            proximoMedico--;
            Pausar();
            return;
        }

        medicos.Add(m);

        Console.WriteLine("\nMedico cadastrado com sucesso!");
        Pausar();
    }

    static void ListarHospitais()
    {
        Console.WriteLine("\n=== HOSPITAIS CADASTRADOS ===");

        if (!hospitais.Any())
        {
            Console.WriteLine("Nenhum hospital cadastrado.");
            return;
        }

        foreach (var h in hospitais)
        {
            Console.WriteLine(
                $"ID: {h.Id} | Nome: {h.Nome} | Localizacao: {h.Localizacao}");
        }
    }

    static void ListarPacientes()
    {
        Console.Clear();
        Console.WriteLine("=== LISTA DE PACIENTES ===");

        foreach (var p in pacientes)
        {
            var hospital = hospitais.FirstOrDefault(
                h => h.Id == p.HospitalId);

            Console.WriteLine(
                $"ID: {p.Id} | Nome: {p.Nome} | Idade: {p.Idade} | " +
                $"Hospital: {hospital?.Nome}");
        }

        if (!pacientes.Any())
            Console.WriteLine("Nenhum paciente cadastrado.");

        Pausar();
    }

    static void ListarMedicos()
    {
        Console.Clear();
        Console.WriteLine("=== LISTA DE MEDICOS ===");

        foreach (var m in medicos)
        {
            var hospital = hospitais.FirstOrDefault(
                h => h.Id == m.HospitalId);

            Console.WriteLine(
                $"ID: {m.Id} | Nome: {m.Nome} | " +
                $"Especialidade: {m.Especialidade} | Hospital: {hospital?.Nome}");
        }

        if (!medicos.Any())
            Console.WriteLine("Nenhum medico cadastrado.");

        Pausar();
    }

    static void RegistarConsulta()
    {
        Console.Clear();
        Console.WriteLine("=== REGISTO DE CONSULTA ===");

        if (!pacientes.Any() || !medicos.Any())
        {
            Console.WriteLine("Necessita de pacientes e medicos cadastrados.");
            Pausar();
            return;
        }

        foreach (var p in pacientes)
            Console.WriteLine($"Paciente ID: {p.Id} - {p.Nome}");

        Console.Write("\nID do paciente: ");

        if (!int.TryParse(Console.ReadLine(), out int pacienteId) ||
            !pacientes.Any(p => p.Id == pacienteId))
        {
            Console.WriteLine("Paciente nao encontrado.");
            Pausar();
            return;
        }

        foreach (var m in medicos)
            Console.WriteLine($"Medico ID: {m.Id} - {m.Nome}");

        Console.Write("\nID do medico: ");

        if (!int.TryParse(Console.ReadLine(), out int medicoId) ||
            !medicos.Any(m => m.Id == medicoId))
        {
            Console.WriteLine("Medico nao encontrado.");
            Pausar();
            return;
        }

        var paciente = pacientes.First(p => p.Id == pacienteId);
        var medico = medicos.First(m => m.Id == medicoId);

        if (paciente.HospitalId != medico.HospitalId)
        {
            Console.WriteLine("O medico pertence a outro hospital.");
            Console.WriteLine("Transfira o paciente antes de registar a consulta.");
            Pausar();
            return;
        }

        Consulta c = new Consulta();

        c.Id = proximaConsulta++;
        c.PacienteId = pacienteId;
        c.MedicoId = medicoId;
        c.Data = DateTime.Now.ToString("dd/MM/yyyy HH:mm");

        Console.Write("Diagnostico: ");
        c.Diagnostico = Console.ReadLine() ?? "";

        Console.Write("Tratamento: ");
        c.Tratamento = Console.ReadLine() ?? "";

        consultas.Add(c);

        paciente.Historico.Add(
            $"Consulta {c.Id} | {c.Data} | Diagnostico: {c.Diagnostico}");

        Console.WriteLine("\nConsulta registada com sucesso!");
        Pausar();
    }

    static void HistoricoClinico()
    {
        Console.Clear();
        Console.WriteLine("=== HISTORICO CLINICO ===");

        Console.Write("ID do paciente: ");

        if (!int.TryParse(Console.ReadLine(), out int id))
        {
            Console.WriteLine("ID invalido.");
            Pausar();
            return;
        }

        var paciente = pacientes.FirstOrDefault(p => p.Id == id);

        if (paciente == null)
        {
            Console.WriteLine("Paciente nao encontrado.");
            Pausar();
            return;
        }

        Console.WriteLine($"\nPaciente: {paciente.Nome}");

        var historico = consultas.Where(c => c.PacienteId == id);

        foreach (var c in historico)
        {
            var medico = medicos.FirstOrDefault(m => m.Id == c.MedicoId);

            Console.WriteLine($"\nConsulta: {c.Id}");
            Console.WriteLine($"Data: {c.Data}");
            Console.WriteLine($"Medico: {medico?.Nome}");
            Console.WriteLine($"Diagnostico: {c.Diagnostico}");
            Console.WriteLine($"Tratamento: {c.Tratamento}");
        }

        if (!historico.Any())
            Console.WriteLine("Sem consultas registadas.");

        Pausar();
    }

    static void PesquisarPaciente()
    {
        Console.Clear();
        Console.WriteLine("=== PESQUISA DE PACIENTE ===");

        Console.Write("Digite o nome do paciente: ");
        string nome = Console.ReadLine() ?? "";

        var resultados = pacientes.Where(
            p => p.Nome.Contains(nome, StringComparison.OrdinalIgnoreCase));

        foreach (var p in resultados)
        {
            Console.WriteLine(
                $"ID: {p.Id} | Nome: {p.Nome} | Idade: {p.Idade} | Sexo: {p.Sexo}");
        }

        if (!resultados.Any())
            Console.WriteLine("Nenhum resultado encontrado.");

        Pausar();
    }

    static void PartilharDados()
    {
        Console.Clear();
        Console.WriteLine("=== PARTILHA DE DADOS ENTRE HOSPITAIS ===");

        if (!hospitais.Any() || !pacientes.Any())
        {
            Console.WriteLine("Nao existem hospitais ou pacientes cadastrados.");
            Pausar();
            return;
        }

        foreach (var p in pacientes)
        {
            Console.WriteLine($"Paciente ID: {p.Id} - {p.Nome}");
        }

        Console.Write("\nID do paciente: ");

        if (!int.TryParse(Console.ReadLine(), out int pacienteId))
        {
            Console.WriteLine("ID invalido.");
            Pausar();
            return;
        }

        var paciente = pacientes.FirstOrDefault(p => p.Id == pacienteId);

        if (paciente == null)
        {
            Console.WriteLine("Paciente nao encontrado.");
            Pausar();
            return;
        }

        Console.WriteLine("\nHospitais disponiveis:");

        foreach (var h in hospitais)
            Console.WriteLine($"ID: {h.Id} - {h.Nome}");

        Console.Write("\nID do hospital de destino: ");

        if (!int.TryParse(Console.ReadLine(), out int destino) ||
            !hospitais.Any(h => h.Id == destino))
        {
            Console.WriteLine("Hospital invalido.");
            Pausar();
            return;
        }

        if (destino == paciente.HospitalId)
        {
            Console.WriteLine("O paciente ja pertence a este hospital.");
            Pausar();
            return;
        }

        var origem = hospitais.First(h => h.Id == paciente.HospitalId);
        var novoHospital = hospitais.First(h => h.Id == destino);

        paciente.HospitalId = destino;

        Console.WriteLine("\nPartilha/transferencia registada com sucesso!");
        Console.WriteLine($"Origem: {origem.Nome}");
        Console.WriteLine($"Destino: {novoHospital.Nome}");
        Console.WriteLine($"Paciente: {paciente.Nome}");

        Pausar();
    }

    static void Relatorios()
    {
        Console.Clear();
        Console.WriteLine("=== RELATORIO GERAL ===");

        Console.WriteLine($"Total de hospitais: {hospitais.Count}");
        Console.WriteLine($"Total de pacientes: {pacientes.Count}");
        Console.WriteLine($"Total de medicos: {medicos.Count}");
        Console.WriteLine($"Total de consultas: {consultas.Count}");

        Console.WriteLine("\nPACIENTES POR HOSPITAL:");

        foreach (var h in hospitais)
        {
            int total = pacientes.Count(p => p.HospitalId == h.Id);

            Console.WriteLine($"{h.Nome}: {total} paciente(s)");
        }

        Pausar();
    }

    static void Pausar()
    {
        Console.WriteLine("\nPressione ENTER para continuar...");
        Console.ReadLine();
    }
}

