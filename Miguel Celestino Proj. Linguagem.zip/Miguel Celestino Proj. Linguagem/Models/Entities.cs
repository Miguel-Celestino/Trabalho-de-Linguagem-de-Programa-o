namespace SistemaIntegradoInformacao.Models;

// Cada classe representa uma entidade principal do sistema.
public class Hospital
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Nome { get; set; } = "";
    public string Provincia { get; set; } = "";
    public string Municipio { get; set; } = "";
    public string Endereco { get; set; } = "";
    public string Telefone { get; set; } = "";
}

public class UnidadeSaude
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid HospitalId { get; set; }
    public string Nome { get; set; } = "";
    public string Tipo { get; set; } = "";
}

public class Utente
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string NumeroUtente { get; set; } = "";
    public string NomeCompleto { get; set; } = "";
    public DateOnly DataNascimento { get; set; }
    public string Sexo { get; set; } = "";
    public string Telefone { get; set; } = "";
    public string Endereco { get; set; } = "";
    public string GrupoSanguineo { get; set; } = "";
}

public class Medico
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string NomeCompleto { get; set; } = "";
    public string Especialidade { get; set; } = "";
    public string NumeroOrdem { get; set; } = "";
    public Guid HospitalId { get; set; }
}

public class Consulta
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UtenteId { get; set; }
    public Guid MedicoId { get; set; }
    public DateTime DataHora { get; set; }
    public string Estado { get; set; } = "Agendada";
    public string Observacoes { get; set; } = "";
}

public class RegistoClinico
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UtenteId { get; set; }
    public Guid MedicoId { get; set; }
    public DateTime DataRegisto { get; set; } = DateTime.Now;
    public string Diagnostico { get; set; } = "";
    public string Tratamento { get; set; } = "";
    public string Observacoes { get; set; } = "";
}

public class PartilhaClinica
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UtenteId { get; set; }
    public Guid HospitalOrigemId { get; set; }
    public Guid HospitalDestinoId { get; set; }
    public DateTime DataPartilha { get; set; } = DateTime.Now;
    public string Motivo { get; set; } = "";
    public string Estado { get; set; } = "Registada";
}

public class Utilizador
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Nome { get; set; } = "";
    public string NomeUtilizador { get; set; } = "";
    public string Salt { get; set; } = "";
    public string HashSenha { get; set; } = "";
    public string Perfil { get; set; } = "Funcionário";
}
