# Sistema Integrado de Informação em Saúde

Aplicação de consola desenvolvida em C#/.NET 10, com persistência local em ficheiros JSON. Não utiliza SQL Server, MongoDB ou qualquer servidor de base de dados.

## Abrir no Visual Studio 2026
1. Extrair o ZIP para uma pasta.
2. Abrir `SistemaIntegradoInformacao.csproj` no Visual Studio 2026.
3. Confirmar que o workload **Desenvolvimento para desktop com .NET** e o SDK .NET 10 estão instalados.
4. Executar com `Ctrl + F5` ou pelo botão **Iniciar**.

Também pode executar no terminal, dentro da pasta:
```bash
dotnet restore
dotnet run
```

## Primeiro acesso
- Utilizador: `admin`
- Palavra-passe: `Admin@123`

Altere a palavra-passe e crie utilizadores próprios depois do primeiro acesso. A palavra-passe inicial só é usada para criar o primeiro administrador quando `Data/utilizadores.json` ainda está vazio.

## Módulos
- Hospitais e unidades de saúde
- Utentes
- Médicos
- Consultas
- Registos clínicos
- Registo de partilha/transferência entre hospitais
- Relatório geral
- Cópia de segurança dos JSON
- Autenticação e perfis básicos

## Onde ficam os dados
A pasta `Data` é criada automaticamente na primeira execução. Cada módulo utiliza o seu próprio ficheiro JSON. As cópias de segurança são guardadas em `Backups`.

## Observações importantes
- Os comentários no código explicam a finalidade das classes e das operações principais.
- A partilha entre hospitais é apenas registada localmente; não existe transmissão real de dados entre instituições.
- Esta é uma versão académica demonstrativa. Antes de qualquer utilização clínica real, são necessários requisitos legais, privacidade, controlo de acesso por unidade, auditoria, encriptação, cópias de segurança testadas e validação por profissionais de saúde.
